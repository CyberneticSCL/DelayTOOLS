% SOSTOOLS -- Sum of Squares Toolbox, internal files
% Version 1.00 
% 11 April 2002.
%

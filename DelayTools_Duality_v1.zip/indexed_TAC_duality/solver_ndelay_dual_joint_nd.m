clear all; close all; echo off; 
total=tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% DelayTools/Linear v.04 - solver_delay_nd
%
% This program determines stablity of a linear differential equation with 
% multiple delays using a dual form of Lyapunov-Krasovskii functional.
% Here \dot{x}(t)=A0x(t)+A{1}x(t-tau(1))+...+A{K}x(t-tau(K))  
% where A0, A{i}, and tau(i) are user inputs. 
%
% Inputs: A{i} - these can be arbitrary square matrices of arbitrary 
%         dimension. However,  the higher the higher the dimension of A{i},
%         the more time the program will take to run
%         
%         tau(i) - These can be an arbitrary sequence of positive increasing 
%         numbers.
%
%         orderth/ordernu - This input controls the accuracy of the results. For
%         most problems, orderth=ordernu=4 should be sufficient to obtain a
%         reasonable degree of accuracy. Note: orderth should be an even
%         integer.
% 
% Requirements: In order to operate, this program requires a working
%               version of SOStools. There are some known compatability 
%               issues with SOStools and Matlab version 7+ due to errors in 
%               the implementation of Maple v8. In addition, it
%               is highly recommended that the user have a compiled version
%               of cdd. Finally the following package of subprograms are
%               required which allows SOStools to handle matrix objects
%               directly:
%               SOStools Matrix Addon package:
%                   sosposmatr.m
%                   sosmateq.m
%                   sosmatrvar.m
%                   sossymmatrvar.m
%                   sosposmatrvar.m
%
% version .03   M. Peet, Arizona State University. mpeet@asu.edu
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
%
% Enter degree of accuracy - must be an even integer
orderth = 4;
ordernu = 4;

% Enter system dynamics in terms of A0, A{1}, ..., A{K}

% % Problem A:
 A0=0;%
 A{1}=-1;%
 tau(1) = 1.5707;

% % Problem B:
% A0=[0 1; -2 .1];
% A{1}=[0 0;1 0];
% tau(1) = .10 %[.10017, 1.71785]

% Problem C:
% A0=-2;%
% A{1}=.1;%
% A{2}=-1;%
% tau(1) = 1;%
% tau(2) = 2;%

% Problem D:
% A0=[0 1; -1 .1];
% A{1}=[0 0;-1 0];
% A{2}=[0 0;1 0];
% tau(2) = 1.30%1.372 is max [1.35,1.372]
% tau(1) = tau(2)/2;


% A0=[0 1; 0 -.1];
% A{1}=[0; .1]*[-3.75 -11.5];
%====================
% Gu 2delay example 1
% A0=[-2 0; 0 -.9];
% A{1}=[-1 0;-1 -1]*.05;
% A{2}=[-1 0;-1 -1]*.95;
% tau(2) = 6.%8.5
% tau(1) = tau(2)/2;
%====================
% Gu 2delay example 2
% A0=[0 1; -1 .1];
% A0=[0 1; -1 .1];
% A{1}=[0 0;-1 0];
% A{2}=[0 0;1 0];
% tau(2) = 1.371%1.372 is max [1.35,1.372]
% tau(1) = tau(2)/2;

%    A0=-2;%[-1 0; 0 0];
%  A{1}=3;%[0 0;0 -1];[2.97]
%  A{2}=-1;%[0 0;0 -1];
%  tau(1) = 1%.57079;
%  tau(2) = 2; %d=2 

%  A0=-1*[-1 0;-1 0];%[-1 0; 0 0];
%  A{1}=-1*[-1 0;-1 0];%[0 0;0 -1];
%  A{2}=-2*[-1 0;-1 0];%[0 0;0 -1];
%  tau(1) = .4%.57079;
%  tau(2) = 6; %d=2 

%  A0=0;%[-1 0; 0 0];
%  A{1}=-1;%[0 0;0 -1];
%  A{2}=-2;%[0 0;0 -1];
%  tau(1) = .4%.57079;
% % tau(2) = .6191; d=2 
%  tau(2) = .64;
%  A0=0;%[-1 0; 0 0];
%  A{1}=-1;%[0 0;0 -1];
%  tau(1) = 1.409%.57079;
%====================
%  A0=[0];
%  A{1}=[-.5];
% A{2}=[-.5];
% tau(1) = 7;
% tau(2) = 7.1;
%  A0=[0];
%  A{1}=[-1];
% A{2}=[0];
% tau(1) = 1.3;
% tau(2) = 8;


%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fact=1/tau;
fact=1;           % conditioning multiplier
eps1=1;           % strictness of lyapunov positivity
eps2=0;           % strictness of derivative negativity

% control inputs to SeDuMi 
pars.alg=2;
pars.stepdif=1;
pars.eps=10^(-10);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal processing:
tic
pvar th ksi

n_dim=length(A0);
n_delay=length(tau);
tauK=tau(n_delay);

mastervartable=[th,ksi];
prog = sosprogram(mastervartable);

% local positivity regions:
g{1}=th*(th+tau(1));            %negative on interval [-\tau,0]
parfor i=2:n_delay
    g{i}=(th+tau(i))*(th+tau(i-1));%negative on interval [-tau_i,-\tau_i-1]
end
II{1}=[-tau(1) 0];            %negative on interval [-\tau,0]
parfor i=2:n_delay
    II{i}=[-tau(i) -tau(i-1)];%negative on interval [-tau_i,-\tau_i-1]
end
% This is the multiple delay case.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% phase 1 - variables %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we will need to declare variables:
% P, Q(th), S(th), R(th,ksi)
%
disp('Overhead and Lyapunov Variables, elapsed time:')

%[prog,P] = sossymmatrvar(prog,monomials(th,0),[n_dim]);
% for i=1:n_delay
% %    eval(['[prog,Q1',int2str(i),'] = sosmatrvar(prog,monomials([fact*th],0:orderth),[n_dim,n_dim]);'])
%      [prog,Q1{i}]=sossymmatrvar(prog,monomials([fact*th],0:orderth),n_dim);
% end
% % for i=1:n_delay
% %     for j=1:n_delay
% %     [prog,Q2{i,j}] = sosmatrvar(prog,monomials([fact*th fact*ksi],0:orderth),[n_dim, n_dim]);
% % %    eval(['[prog,Q2',int2str(i),int2str(j),'] = sossymmatrvar(prog,monomials([fact*th],0:orderth),[n_dim]);'])
% %     end
% % end
% for i=1:n_delay
%     for j=1:n_delay %j>i
%     [prog,Q2t{i,j}] = sosmatrvar(prog,monomials([fact*th fact*ksi],0:orderth),[n_dim, n_dim]);
%     end
% end
% for i=1:n_delay
%     for j=1:n_delay %j<i
%         Q2{i,j}=.5*(Q2t{i,j}+var_swap(Q2t{j,i}.',th,ksi)); % enforce 
%     end
% end
% 
% for i=1:n_delay
%         bigP{i}=[tau(n_delay)*subs(subs(Q2{1,1},ksi,0),th,0)+subs(Q1{1},th,0), tau(n_delay)*subs(var_swap(Q2{1,i},ksi,th),ksi,0); tau(n_delay)*subs(Q2{i,1},ksi,0) Q1{i}]; %mod for new pvar
% end
% 
% for i=1:n_delay
%     for j=1:n_delay %j>i
%     [prog,Q2t{i,j}] = sosmatrvar(prog,monomials([fact*th fact*ksi],0:orderth),[n_dim, n_dim]);
%     end
% end
% 
% for i=1:n_delay
%     for j=1:n_delay %j<i
%         Q2{i,j}=.5*(Q2t{i,j}+var_swap(Q2t{j,i}.',th,ksi)); % enforce 
%     end
% end
% % 
% % 
% % for i=1:n_delay
% %     for j=i:n_delay %j>i
% %     [prog,Q2{i,j}] = sosmatrvar(prog,monomials([fact*th fact*ksi],0:orderth),[n_dim, n_dim]);
% %     end
% % end
% % 
% % 
% % for i=1:n_delay
% %     for j=1:(i-1) %j<i
% %         Q2{i,j}=var_swap(Q2{j,i}.',th,ksi); % enforce 
% %     end
% % end
% [prog,P11]=sossymmatrvar_p(prog,[polynomial(1)],n_dim);
% 
% for i=1:n_delay
%        [prog,P12{i}] = sosmatrvar(prog,monomials([fact*th],0:orderth),[n_dim, n_dim]);
%        [prog, P22{i}]=sossymmatrvar(prog,monomials([fact*th],0:orderth),n_dim); %mod for new pvar
%        bigP{i}=[P11 P12{i}; P12{i}.' P22{i}];
% end
% %bigP{i}=
% 
% Nw=Q2; % our kernel is Q2 in this case, but lets keep it general
toc
disp('creating joint positive operator variable')
tic
% For the dual variables, we are going to take the brute force approach. We
% are going to create the pieces individually and then constrain them to be
% positive using a separate set of variables.
% P           Q_i(s)
% Q_i(s)^T    S_i(s)    R_{ij}(s,\theta)
% However, only R_{ij} and S_i are truly independent

% There are two constraints that the variables must satisfy: 
% P=\tau_kQ_i(0)^T + \tau_k S_i(0)   for all i
% Q_i(s)=R_{j,i}(0,s)                for all i,j

for i=1:n_delay
    [prog,S{i}] = sossymmatrvar(prog,monomials([fact*th],0:orderth),[n_dim]);
    for j=1:n_delay
        [prog,R{i,j}] = sosmatrvar(prog,monomials([th,ksi],0:orderth),[n_dim n_dim]);
    end
    Q{i}=subs(var_swap(R{1,i},th,ksi),ksi,0);
end
P=tauK*subs(Q{1}.',th,0)+tauK*subs(S{1},th,0); % the first i=1 defines P
for i=2:n_delay % the latter i define constraints
    prog = sosmateq(prog,P-(tauK*subs(Q{i}.',th,0)+tauK*subs(S{i},th,0)));   
end

for i=1:n_delay
%    Q{i}=subs(var_swap(R{1,i},th,ksi),ksi,0); % the first j=1 defines Q_i
    for j=2:n_delay % the latter j>1 define constraints
    prog = sosmateq(prog,Q{i}-subs(var_swap(R{j,i},th,ksi),ksi,0));
    end
end

for i=1:n_delay
%    Q{i}=subs(var_swap(R{1,i},th,ksi),ksi,0); % the first j=1 defines Q_i
    for j=1:n_delay % the latter j>1 define constraints
    prog = sosmateq(prog,R{i,j}-var_swap(R{j,i},th,ksi).');
    end
end


toc
disp('creating joint positive operator variable')
tic
%[prog, M, N] = sospos_mat_ker_ndelay(prog,2*n_dim,orderth/2,ordernu/2,th,ksi,II);
[prog, M, N] = sosjointpos_mat_ker_ndelay_parallel(prog,2*n_dim,orderth/2,ordernu/2,th,ksi,II);
%[prog, M, N] = sosjointpos_mat_ker_ndelay_backup(prog,2*n_dim,orderth/2,ordernu/2,th,ksi,II);
toc


disp('manipulating variables, elapsed time:')
tic
for i=1:n_delay
    parfor j=1:n_delay
        N11{i,j}=N{i,j}(1:n_dim,1:n_dim);
        N12{i,j}=N{i,j}(1:n_dim,(n_dim+1):2*n_dim);
        N21{i,j}=N{i,j}((n_dim+1):2*n_dim,1:n_dim);
        Nw{i,j}=N{i,j}((n_dim+1):2*n_dim,(n_dim+1):2*n_dim);
    end
end
zzn=polynomial(zeros(n_dim));
Mex11=zzn;
% Here we are moving the 11, 12, and 21 pieces of the joint integral term N
% over to the multiplier part. Mex will be added to the multiplier
for i=1:n_delay
    Mex12{i}=zzn;
    for j=1:n_delay
        Mex11=Mex11+int(int(N11{i,j},th,II{i}(1),II{i}(2)),ksi,II{j}(1),II{j}(2)); 
        Mex12{i}=Mex12{i}+int(var_swap(N12{j,i},th,ksi),ksi,II{j}(1),II{j}(2));
%        Mex21{j}=Mex12{i}.';
    end
end
Mex11=Mex11/tau(n_delay);
for i=1:n_delay
    Mex21{i}=zzn;
     for j=1:n_delay
        Mex21{i}=Mex21{i}+int(N21{i,j},ksi,II{j}(1),II{j}(2));
     end
end

% local positivity multipliers, s1 and s2. This adds a locally positive
% multiplier to the multiplier part. This too, will be added. This does
% NOT, however, use the P-Satz construction defined for PDEs and hence may
% be conservative.


if orderth>0
    for i=1:n_delay
%        eval(['[prog,bigs',int2str(i),'] = sosposmatrvar(prog,2*n_dim,orderth-2,[th]);'])
        [prog,bigS{i}] = sosposmatrvar(prog,2*n_dim,orderth-2,[th]);
    end
else
    for i=1:n_delay
%        eval(['bigs',int2str(i),'=blkdiag(zzn,zzn);'])
        bigS{i}=polynomial(zeros(2*n_dim));
    end
end
Mp11i=zzn;
 for i=1:n_delay
    Mp{i}=M{i}-g{i}*bigS{i};
    Mp11{i}=Mp{i}(1:n_dim,1:n_dim);
    Mp12{i}=Mp{i}(1:n_dim,(n_dim+1):2*n_dim);
    Mp21{i}=Mp{i}((n_dim+1):2*n_dim,1:n_dim);
    Mp22{i}=Mp{i}((n_dim+1):2*n_dim,(n_dim+1):2*n_dim);
    Mp11i=Mp11i+int(Mp11{i},th,II{i}(1),II{i}(2)); % condensing the 11 term to a scalar
 end
  parfor i=1:n_delay
    bigP{i}=[Mp11i/tau(n_delay)+Mex11+eps1*eye(n_dim) Mp12{i}+Mex12{i};Mp21{i}+Mex21{i} Mp22{i}]; 
    % this is the final form of the multiplier part and exists inside the integral, so V=\int_I_i bigP{i}
  end

% bigP{2}=bigP{2};
% Nw{1,2}=Nw{1,2}
% Nw{2,2}=Nw{2,2}
% Nw{2,1}=Nw{2,1}
 
%  % Should we make this exact?
% toc
% disp('running equalities, elapsed time:')
% tic
% 
% for i=1:n_delay
%     [prog] = sosmateq(prog,H1{i}-bigP{i});
% end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we first construct the variable R
% First declare a monomial basis for R

% for i=1:n_delay
%     for j=1:n_delay
%         [prog] = sosmateq(prog,Q2{i,j}-N22{i,j});
%     end
% end

zzn=polynomial(zeros(n_dim));
P11=bigP{1}(1:n_dim,1:n_dim);
parfor i=1:n_delay   % these are the pieces of bigP{i}
    P12{i}=bigP{i}(1:n_dim,(n_dim+1):(2*n_dim));
    P21{i}=bigP{i}((n_dim+1):(2*n_dim),1:n_dim);%P12{i}.';
    P22{i}=bigP{i}((n_dim+1):(2*n_dim),(n_dim+1):(2*n_dim));
end

%%%%%%%%%%%%%%%%%
% Now we equate Pij and Nw to the P,Q,S, and R
prog=sosmateq(prog,P11-P);
taup=[0 tau];
for i=1:n_delay
     b{i}=-taup(i);
     a{i}=(-taup(i+1)-b{i})/(-taup(i+1));
end
for i=1:n_delay
     prog=sosmateq(prog, tauK/a{i}*subs(Q{i},th,(th-b{i})/a{i})-P12{i});
     prog=sosmateq(prog, tauK/a{i}*subs(Q{i}.',th,(th-b{i})/a{i})-P21{i});
     prog=sosmateq(prog, tauK/a{i}*subs(S{i},th,(th-b{i})/a{i})-P22{i});
     for j=1:n_delay
         prog=sosmateq(prog,subs(subs(1/a{i}/a{j}*R{i,j},th,(th-b{i})/a{i}),ksi,(ksi-b{j})/a{j})-Nw{i,j});
     end
end

toc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% phase 2 - derivatives %%%%%%%%%%%%%%%%%%%%
%%%%%%% Step1 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the derivative matrices are spelled out in the paper, they are 
disp('constructing Derivatives, elapsed time:')
tic

% first do the constant terms. These are inside the integral.
D11=A0*P+P*A0.';
D12=[];
D22=[];
for i=1:n_delay
    D11=D11+tauK*A{i}*subs(Q{i}.',th,-tau(i))+tauK*subs(Q{i},th,-tau(i))*A{i}.'+subs(S{i},th,0);
    D12=[D12 tauK*A{i}*subs(S{i},th,-tau(i))]; 
    D22=blkdiag(D22,(subs(-S{i},th,-tau(i))));
end
D21=D12.';


parfor i=1:n_delay
    D13{i}=tauK*A0*Q{i} + tauK*diff(Q{i},th);
    for j=1:n_delay
         D13{i}=D13{i}+tauK*A{j}*subs(var_swap(R{j,i},th,ksi),ksi,-tau(j));
    end
    D31{i}=D13{i}.';
    D23{i}=polynomial(zeros(n_delay*n_dim,n_dim));
    D33{i}=tauK*diff(S{i},th);
    D32{i}=D23{i}.';
end


parfor i=1:n_delay
    for j=1:n_delay
        G{i,j}=(diff(R{i,j},th)+diff(var_swap(R{j,i}.',th,ksi),ksi));
    end
end

toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enforce negativity of D 
disp('enforcing negativity of derivative')
%Now declare first spacing functions

%[prog, M, N] = sosjointpos_mat_ker_ndelay(prog,2*n_dim,orderth/2,ordernu/2,th,ksi,II);
disp('Calling for jointly positive Mat/Kernel, elapsed time:')
% 
% 
tic
%[prog, F, R] = sospos_mat_ker_ndelay(prog,(n_delay+2)*n_dim,orderth/2,ordernu/2,th,ksi,II);
[prog, F, RR] = sosjointpos_mat_ker_ndelay_parallel(prog,(n_delay+2)*n_dim,orderth/2,ordernu/2,th,ksi,II);
toc

disp('Manipulating variables, elapsed time:')
%job array
tic
ij_iter=0;
n_iter=n_delay^2;
niter=n_delay^2;
for i=1:n_delay
    for j=1:n_delay
        ij_iter=ij_iter+1;
        Ic(ij_iter)=i; % translates ij index to i index
            Jc(ij_iter)=j;% translates ij index to j index
            IJc(i,j)=ij_iter; % translates i,j indices to ij indices
    end
end 

% parfor ij=1:n_iter %Ic(ij)=i and Jc(ij)=j
%         R11{Ic(ij),Jc(ij)}=RR{Ic(ij),Jc(ij)}(1:(n_dim*(n_delay+1)),1:(n_dim*(n_delay+1)));
%         R12{Ic(ij),Jc(ij)}=RR{Ic(ij),Jc(ij)}(1:(n_dim*(n_delay+1)),(n_dim*(n_delay+1)+1):((n_delay+2)*n_dim));
%         R21{Ic(ij),Jc(ij)}=RR{Ic(ij),Jc(ij)}((n_dim*(n_delay+1)+1):((n_delay+2)*n_dim),1:(n_dim*(n_delay+1)));
%         R22{Ic(ij),Jc(ij)}=RR{Ic(ij),Jc(ij)}((n_dim*(n_delay+1)+1):((n_delay+2)*n_dim),(n_dim*(n_delay+1)+1):((n_delay+2)*n_dim));
% end


for i=1:n_delay
    parfor j=1:n_delay
        R11{i,j}=RR{i,j}(1:(n_dim*(n_delay+1)),1:(n_dim*(n_delay+1)));
        R12{i,j}=RR{i,j}(1:(n_dim*(n_delay+1)),(n_dim*(n_delay+1)+1):((n_delay+2)*n_dim));
        R21{i,j}=RR{i,j}((n_dim*(n_delay+1)+1):((n_delay+2)*n_dim),1:(n_dim*(n_delay+1)));
        R22{i,j}=RR{i,j}((n_dim*(n_delay+1)+1):((n_delay+2)*n_dim),(n_dim*(n_delay+1)+1):((n_delay+2)*n_dim));
    end
end

Dex11=polynomial(zeros(n_dim*(n_delay+1)));

toc
tic
parfor ij=1:niter
        i=Ic(ij);j=Jc(ij);
        Dex11it{ij}=int(int(R11{i,j},th,II{i}(1),II{i}(2)),ksi,II{j}(1),II{j}(2));
        Dex12it{ij}=subs(int(R12{j,i},th,II{j}(1),II{j}(2)),ksi,th);
%        Dex21{j}=Dex12{i}.';
end

parfor i=1:n_delay
    Dex12{i}=polynomial(zeros(n_dim*(n_delay+1),n_dim));
    for j=1:n_delay
        Dex11=Dex11+Dex11it{IJc(i,j)};
        Dex12{i}=Dex12{i}+Dex12it{IJc(i,j)};
%        Dex21{j}=Dex12{i}.';
    end
end

Dex11=Dex11/tau(n_delay);
 parfor i=1:n_delay
    Dex21{i}=polynomial(zeros(n_dim,n_dim*(n_delay+1)));
     for j=1:n_delay
        Dex21{i}=Dex21{i}+int(R21{i,j},ksi,II{j}(1),II{j}(2));
     end
 end
toc
tic
 if orderth>0
    for i=1:n_delay
        [prog,bigSD{i}] = sosposmatrvar(prog,(n_delay+2)*n_dim,orderth-2,[th]);
    end
else
    for i=1:n_delay
%        eval(['bigs',int2str(i),'=blkdiag(zzn,zzn);'])
        bigSD{i}=polynomial(zeros((n_delay+2)*n_dim));
    end
end
toc
tic
Fp11i=polynomial(zeros((n_delay+1)*n_dim));
 parfor i=1:n_delay
    Fp{i}=F{i}-g{i}*bigSD{i};
    Fp11{i}=Fp{i}(1:(n_dim*(n_delay+1)),1:(n_dim*(n_delay+1)));
    Fp12{i}=Fp{i}(1:(n_dim*(n_delay+1)),(n_dim*(n_delay+1)+1):((n_delay+2)*n_dim));
    Fp21{i}=Fp{i}((n_dim*(n_delay+1)+1):((n_delay+2)*n_dim),1:(n_dim*(n_delay+1)));
    Fp22{i}=Fp{i}((n_dim*(n_delay+1)+1):((n_delay+2)*n_dim),(n_dim*(n_delay+1)+1):((n_delay+2)*n_dim));
  end
  for i=1:n_delay
    Fp11i=Fp11i+int(Fp11{i},th,II{i}(1),II{i}(2));
  end
toc 
% tic
% parfor i=1:n_delay
% %    H1{i}=[Mp11i/tau(n_delay)+Mex11+eps1*speye(n_dim) Mp12{i}+Mex12{i};Mp21{i}+Mex21{i} Mp22{i}];
%     HH{i}=[Fp11i/tau(n_delay)+Dex11 Fp12{i}+Dex12{i};Fp21{i}+Dex21{i} Fp22{i}];
% end
% toc
disp('running equalities, elapsed time:')
tic
% Now, we transform the derivative to a form compatable with the
% piecewise-polynomial formulation (as before) in HH
prog=sosmateq(prog,[D11 D12;D21 D22]+(Fp11i/tau(n_delay)+Dex11));
taup=[0 tau];
%for i=1:n_delay
toc
tic
parfor i=1:n_delay
     b{i}=-taup(i);
     a{i}=(-taup(i+1)-b{i})/(-taup(i+1));
end

parfor i=1:n_delay
     eq12{i}=1/a{i}*subs([D13{i};D23{i}],th,(th-b{i})/a{i})+Fp12{i}+Dex12{i};
     eq21{i}=1/a{i}*subs([D31{i} D32{i}],th,(th-b{i})/a{i})+Fp21{i}+Dex21{i};
     eq22{i}=1/a{i}*subs(D33{i},th,(th-b{i})/a{i})+Fp22{i};
end 

parfor ij=1:n_iter
     eqR22G{ij}=subs(subs(1/a{Ic(ij)}/a{Jc(ij)}*G{Ic(ij),Jc(ij)},th,(th-b{Ic(ij)})/a{Ic(ij)}),ksi,(ksi-b{Jc(ij)})/a{Jc(ij)})+R22{Ic(ij),Jc(ij)};
end
toc
tic
for i=1:n_delay
     prog=sosmateq(prog, eq12{i});
     prog=sosmateq(prog, eq21{i});
     prog=sosmateq(prog, eq22{i});
end 
     clear eq12 eq21 eq22

for ij=1:n_iter
      prog=sosmateq(prog,eqR22G{ij});
end
      clear eqR22G


% Should we make this exact?
toc
disp('running equalities, elapsed time:')
tic

% for i=1:n_delay
%     [prog] = sosmateq(prog,HH{i}+D{i});
%     for j=1:n_delay
%                 [prog] = sosmateq(prog,R22{i,j}+G{i,j});
%     end
% end
toc
disp('TOTAL POLYNOMIAL TIME:')
toc(total)
disp('Computing Solution')


disp('Computing Solution')
prog = sossolve(prog);
%prog = sossolve(prog,[],[],'mosek');
%% Conclusion:
if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
    disp('The System is STABLE.')
elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
    disp('The System is likely STABLE. However, Double-check the precision.')
elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
    disp('The System is probably NOT STABLE.')
else
    disp('Unable to definitively determine stability. Numerical errors dominating or at the limit of stability.')
end
% 
% 
%  nP=sosgetsol(prog,P);
% nG11=sosgetsol(prog,G{1,1})
% 
% nRR2211=sosgetsol(prog,R22{1,1})

 
 


%  % % First check positivity of the functional

% Pn=sosgetsol(prog,P);
% for i=1:n_delay
%     Qn{i}=sosgetsol(prog,Q{i});
%     Sn{i}=sosgetsol(prog,S{i});
%     for j=i:n_delay
%         Rn{i,j}=sosgetsol(prog,R{i,j});
%     end
% end
% parfor k=1:1000
%  ndim=length(Q{1});
%  nvec=6;
%         xtest=(-10 + (10+10).*rand(nvec,ndim))'*monomials([th],0:(nvec-1));
%      xtestksi=subs(xtest,th,ksi);
% % for i=1:n_delay
% %         xtest{i}=(-10 + (10+10).*rand(nvec,ndim))'*monomials([th],0:(nvec-1));
% %     xtestksi{i}=subs(xtest{i},th,ksi);
% % end
%     xtest0=subs(xtest,th,0);
% i1temp=tauK*xtest0.'*Pn*xtest0;
% i2temp=0;
% i3temp=0;
% i4temp=0;
% i5temp=0;
% 
% %
% for i=1:n_delay
%     i2temp=i2temp+tauK*int(xtest0.'*Qn{i}*xtest,th,-tau(i),0);
%     i3temp=i3temp+tauK*int(xtest.'*Qn{i}.'*xtest0,th,-tau(i),0);
%     i4temp=i4temp+tauK*int(xtest.'*Sn{i}.'*xtest,th,-tau(i),0);
%     for j=i:n_delay
%         i5temp=i5temp+int(int(xtest.'*Rn{i,j}*xtestksi,th,-tau(i),0),ksi,-tau(j),0);
%     end
% end
% % i1temp
% % i2temp
% % i3temp
% % i4temp
% % i5temp
% sum(k)=i1temp+i2temp+i3temp+i4temp+i5temp;
% end
% min(double(sum))


% %  % % check negativity of the derivative
% 
% 
% % D11=A0*P+P*A0';
% % D12=[];
% % D22=[];
% % for i=1:n_delay
% %     D11=D11+tauK*A{i}*subs(Q{i},th,-tau(i)).'+tauK*subs(Q{i}.',th,-tau(i))*A{i}.'+subs(S{i},th,0);
% %     D12=[D12 tauK*A{i}*subs(S{i},th,-tau(i))]; 
% %     D22=blkdiag(D22,(subs(-S{i},th,-tau(i))));
% % end
% % D21=D12.';
% % 
% % parfor i=1:n_delay
% %     D13{i}=tauK*A0*Q{i} + tauK*diff(Q{i},th);
% %     for j=1:n_delay
% %          D13{i}=D13{i}+tauK*A{j}*subs(var_swap(R{j,i},th,ksi),ksi,-tau(j));
% %     end
% %     D31{i}=D13{i}.';
% %     D23{i}=polynomial(zeros(n_delay*n_dim,n_dim));
% %     D33{i}=tauK*diff(S{i},th);
% %     D32{i}=D23{i}.';
% % end
% % 
% % parfor i=1:n_delay
% %     for j=1:n_delay
% %         G{i,j}=(diff(R{i,j},th)+diff(var_swap(R{j,i}.',th,ksi),ksi));
% %     end
% % end
% 
% 
% D11n=sosgetsol(prog,D11);
% for i=1:n_delay
%     D12n{i}=sosgetsol(prog,tauK*A{i}*subs(S{i},th,-tau(i)));
%     D22n{i}=sosgetsol(prog,(subs(-S{i},th,-tau(i))));
% 
% %    Dn{i}=sosgetsol(prog,[D11 D12 D13{i}; D21 D22 D23{i}; D31{i} D32{i} D33{i}]);
%     D13n{i}=sosgetsol(prog,D13{i});
%     D31n{i}=sosgetsol(prog,D31{i});
%     D33n{i}=sosgetsol(prog,D33{i});
%     Sn{i}=sosgetsol(prog,S{i});
%     for j=i:n_delay
%         Gn{i,j}=sosgetsol(prog,G{i,j});
%     end
% end
% for k=1:400
%  ndim=length(D11);
%  nvec=6;
%         xtest=(-1 + (1+1).*rand(nvec,ndim))'*monomials([th],0:(nvec-1));
%      xtestksi=subs(xtest,th,ksi);
%     xtest0=subs(xtest,th,0);
%     xtestd{1}=subs(xtest,th,-tau(1));
%     xtestd{2}=subs(xtest,th,-tau(2));
% i1temp=tauK*xtest0.'*D11n*xtest0;
% 
% i2temp=0;
% i3temp=0;
% i4temp=0;
% i5temp=0;
% i6temp=0;
% i7temp=0;
% for i=1:n_delay
%     i2temp=i2temp+tauK*xtest0.'*D12n{i}*xtestd{i}+tauK*xtestd{i}.'*D12n{i}.'*xtest0 ;
%     i3temp=i3temp+tauK*xtestd{i}.'*D22n{i}*xtestd{i} ;
%     i4temp=i4temp+int(xtest0.'*D13n{i}*xtest,th,-tau(i),0);
%     i5temp=i5temp+int(xtest.'*D31n{i}.'*xtest0,th,-tau(i),0);
%     i6temp=i6temp+int(xtest.'*D33n{i}.'*xtest,th,-tau(i),0);
%     for j=i:n_delay
%         i7temp=i7temp+int(int(xtest.'*Gn{i,j}*xtestksi,th,-tau(i),0),ksi,-tau(j),0);
%     end
% end
% % i1temp
% % i2temp
% % i3temp
% % i4temp
% % i5temp
% dsum(k)=i1temp+i2temp+i3temp+i4temp+i5temp+i6temp+i7temp;
% end
% max(double(dsum))
% 
% % Try it without the adjoint
% % D11=A0*P+P*A0';
% % D12=[];
% % D22=[];
% % for i=1:n_delay
% %     D11=D11+tauK*A{i}*subs(Q{i},th,-tau(i))+tauK*subs(Q{i}.',th,-tau(i))*A{i}.'+subs(S{i},th,0);
% %     D12=[D12 tauK*A{i}*subs(S{i},th,-tau(i))]; 
% %     D22=blkdiag(D22,(subs(-S{i},th,-tau(i))));
% % end
% % D21=D12.';
% % 
% % parfor i=1:n_delay
% %     D13{i}=tauK*A0*Q{i} + tauK*diff(Q{i},th);
% %     for j=1:n_delay
% %          D13{i}=D13{i}+tauK*A{j}*subs(var_swap(R{j,i},th,ksi),ksi,-tau(j));
% %     end
% %     D31{i}=D13{i}.';
% %     D23{i}=polynomial(zeros(n_delay*n_dim,n_dim));
% %     D33{i}=tauK*diff(S{i},th);
% %     D32{i}=D23{i}.';
% % end
% % 
% % parfor i=1:n_delay
% %     for j=1:n_delay
% %         G{i,j}=(diff(R{i,j},th)+diff(var_swap(R{j,i}.',th,ksi),ksi));
% %     end
% % end
% 
% D11n=tauK*sosgetsol(prog,A0*P);
% for i=1:n_delay
%     D11n=D11n+sosgetsol(prog,tauK^2*A{i}*subs(Q{i},th,-tau(i)).'+tauK/2*subs(S{i},th,0));
%     D12n{i}=sosgetsol(prog,tauK^2*A{i}*subs(S{i},th,-tau(i)));
%     D22n{i}=sosgetsol(prog,tauK/2*(subs(-S{i},th,-tau(i))));
% 
% %    Dn{i}=sosgetsol(prog,[D11 D12 D13{i}; D21 D22 D23{i}; D31{i} D32{i} D33{i}]);
%     D13n{i}=sosgetsol(prog,tauK*A0*Q{i} + tauK*diff(Q{i},th));
%     for j=1:n_delay
%          D13n{i}=D13n{i}+sosgetsol(prog,tauK*A{j}*subs(var_swap(R{j,i},th,ksi),ksi,-tau(j)));
%     end
% %    D31n{i}=sosgetsol(prog,D31{i});
%     D33n{i}=sosgetsol(prog,tauK/2*diff(S{i},th));
% %    Sn{i}=sosgetsol(prog,S{i});
%     for j=i:n_delay
%         Din{i,j}=sosgetsol(prog,diff(R{i,j},th));
%     end
% end
% for k=1:400
%  ndim=length(D11);
%  nvec=6;
%         xtest=(-1 + (1+1).*rand(nvec,ndim))'*monomials([th],0:(nvec-1));
%      xtestksi=subs(xtest,th,ksi);
%     xtest0=subs(xtest,th,0);
%     xtestd{1}=subs(xtest,th,-tau(1));
%     xtestd{2}=subs(xtest,th,-tau(2));
% i1temp=xtest0.'*D11n*xtest0;
% 
% i2temp=0;
% i3temp=0;
% i4temp=0;
% i5temp=0;
% i6temp=0;
% i7temp=0;
% for i=1:n_delay
%     i2temp=i2temp+xtest0.'*D12n{i}*xtestd{i};
%     i3temp=i3temp+xtestd{i}.'*D22n{i}*xtestd{i} ;
%     i4temp=i4temp+int(xtest0.'*D13n{i}*xtest,th,-tau(i),0);
% %    i5temp=i5temp+int(xtest.'*D31n{i}.'*xtest0,th,-tau(i),0);
%     i6temp=i6temp+int(xtest.'*D33n{i}.'*xtest,th,-tau(i),0);
%     for j=i:n_delay
%         i7temp=i7temp+int(int(xtest.'*Din{i,j}*xtestksi,th,-tau(i),0),ksi,-tau(j),0);
%     end
% end
% % i1temp
% % i2temp
% % i3temp
% % i4temp
% % i5temp
% dsum(k)=i1temp+i2temp+i3temp+i4temp+i5temp+i6temp+i7temp;
% end
% max(double(dsum))





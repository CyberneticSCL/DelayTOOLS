clear all; close all; echo off; 
total=tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% DelayTools/Linear v.04 - solver_ndelay_dual_joint_nd_simple
%
% NOTE!!!!! WARNING!!!! This is an naive implementation designed to conceptually
% resemble the stability conditions in the paper: SOS Methods for
% multi-delay systems: A Dual Lyapunov Krasovskii Functional. As such, it
% is inefficient and has many unnecessary variables. For practical usage,
% use solver_ndelay_dual_joint_nd
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This program determines stablity of a linear differential equation with 
% multiple delays using a dual form of Lyapunov-Krasovskii functional.
% Here \dot{x}(t)=A0x(t)+A{1}x(t-tau(1))+...+A{K}x(t-tau(K))  
% where A0, A{i}, and tau(i) are user inputs. 
%
% Inputs: A{i} - these can be arbitrary square matrices of arbitrary 
%         dimension. However,  the higher the higher the dimension of A{i},
%         the more time the program will take to run
%         
%         tau(i) - These can be an arbitrary sequence of positive increasing 
%         numbers.
%
%         orderth/ordernu - This input controls the accuracy of the results. For
%         most problems, orderth=ordernu=4 should be sufficient to obtain a
%         reasonable degree of accuracy. Note: orderth should be an even
%         integer.
% 
% Requirements: In order to operate, this program requires a working
%               version of SOStools. There are some known compatability 
%               issues with SOStools and Matlab version 7+ due to errors in 
%               the implementation of Maple v8. In addition, it
%               is highly recommended that the user have a compiled version
%               of cdd. Finally the following package of subprograms are
%               required which allows SOStools to handle matrix objects
%               directly:
%               SOStools Matrix Addon package:
%                   sosposmatr.m
%                   sosmateq.m
%                   sosmatrvar.m
%                   sossymmatrvar.m
%                   sosposmatrvar.m
%
% version .03   M. Peet, Arizona State University. mpeet@asu.edu
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
%
% Enter degree of accuracy - must be an even integer
orderth = 2;
ordernu = 2;
%
% Enter system dynamics in terms of A0, A{1}, ..., A{K}

% % Problem A:
%  A0=0;%
%  A{1}=-1;%
%  tau(1) = 1.5707;

% % Problem B:
% A0=[0 1; -2 .1];
% A{1}=[0 0;1 0];
% tau(1) = .10 %[.10017, 1.71785]

% Problem C:
A0=-2;%
A{1}=2;%
A{2}=-1;%
tau(1) = 1;%
tau(2) = 2;%

% Problem D:
% A0=[0 1; -1 .1];
% A{1}=[0 0;-1 0];
% A{2}=[0 0;1 0];
% tau(2) = 1.30%1.372 is max [1.35,1.372]
% tau(1) = tau(2)/2;

%====================


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fact=1/tau;
fact=1;           % conditioning multiplier
eps1=1;           % strictness of lyapunov positivity
eps2=0;           % strictness of derivative negativity

% control inputs to SeDuMi 
pars.alg=2;
pars.stepdif=1;
pars.eps=10^(-10);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal processing:
pvar th ksi

n_dim=length(A0);
n_delay=length(tau);
tauK=tau(n_delay);

mastervartable=[th,ksi];
prog = sosprogram(mastervartable);

% local positivity regions:
g{1}=-th*(th+tau(1));            %non-negative on interval [-\tau,0]
parfor i=2:n_delay
    g{i}=(th+tau(i))*(-tau(i-1)-th);%non-negative on interval [-tau_i,-\tau_i-1]
end
II{1}=[-tau(1) 0];            
parfor i=2:n_delay
    II{i}=[-tau(i) -tau(i-1)];
end
% This is the multiple delay case.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% phase 1 - variables %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we will need to declare variables:
% P, Q(th), S(th), R(th,ksi)
%

zzn=polynomial(zeros(n_dim,n_dim));
zznK=polynomial(zeros(n_dim*(n_delay+1),n_dim*(n_delay+1)));
zz3=polynomial(zeros(n_dim*(n_delay+1),n_dim));

disp('creating joint positive operator variable')
tic
% For the dual variables, we are going to take the brute force approach. We
% are going to create the pieces individually and then constrain them to be
% positive using a separate set of variables.
% P           Q_i(s)
% Q_i(s)^T    S_i(s)    R_{ij}(s,\theta)
% However, only R_{ij} and S_i are truly independent

% There are two constraints that the variables must satisfy: 
% P=\tau_kQ_i(0)^T + \tau_k S_i(0)   for all i
% Q_i(s)=R_{j,i}(0,s)                for all i,j

for i=1:n_delay
    [prog,S{i}] = sossymmatrvar(prog,monomials([fact*th],0:orderth),[n_dim]);
    for j=1:n_delay
        [prog,R{i,j}] = sosmatrvar(prog,monomials([th,ksi],0:orderth),[n_dim n_dim]);
    end
    Q{i}=subs(var_swap(R{1,i},th,ksi),ksi,0);
end
P=tauK*subs(Q{1}.',th,0)+tauK*subs(S{1},th,0); % the first i=1 defines P
for i=2:n_delay % the latter i define constraints
    prog = sosmateq(prog,P-(tauK*subs(Q{i}.',th,0)+tauK*subs(S{i},th,0)));   
end

for i=1:n_delay
%    Q{i}=subs(var_swap(R{1,i},th,ksi),ksi,0); % the first j=1 defines Q_i
    for j=2:n_delay % the latter j>1 define constraints
    prog = sosmateq(prog,Q{i}-subs(var_swap(R{j,i},th,ksi),ksi,0));
    end
end

for i=1:n_delay
%    Q{i}=subs(var_swap(R{1,i},th,ksi),ksi,0); % the first j=1 defines Q_i
    for j=1:n_delay % the latter j>1 define constraints
    prog = sosmateq(prog,R{i,j}-var_swap(R{j,i},th,ksi).');
    end
end


toc
disp('creating joint positive operator variable')
tic
[prog, M, N] = sosjointpos_mat_ker_ndelay_parallel(prog,2*n_dim,orderth/2,ordernu/2,th,ksi,II);
toc


[prog, F1, H1] = sosspacing_mat_ker_ndelay(prog,n_dim,n_dim,orderth,orderth*2,th,ksi,II);

taup=[0 tau];
for i=1:n_delay
     b{i}=-taup(i);
     a{i}=(-taup(i+1)-b{i})/(-taup(i+1));
end
for i=1:n_delay
    M0{i}=[ P-eps1*eye(n_dim) tauK/a{i}*subs(Q{i},th,(th-b{i})/a{i});
        tauK/a{i}*subs(Q{i}.',th,(th-b{i})/a{i}) tauK/a{i}*subs(S{i},th,(th-b{i})/a{i})]; 
     for j=1:n_delay
         N0{i,j}=subs(subs(1/a{i}/a{j}*R{i,j},th,(th-b{i})/a{i}),ksi,(ksi-b{j})/a{j});
     end
end

if orderth>0
    for i=1:n_delay
        [prog,bigS{i}] = sosposmatrvar(prog,2*n_dim,orderth-2,[th]);
    end
else
    for i=1:n_delay
        bigS{i}=polynomial(zeros(2*n_dim));
    end
end


for i=1:n_delay
    prog = sosmateq(prog,-M{i}+M0{i}+F1{i}-g{i}*bigS{i});
    for j=1:n_delay % the latter j>1 define constraints
    prog = sosmateq(prog,-N{i,j}+[zzn zzn; zzn N0{i,j}]+H1{i,j});
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% phase 2 - derivatives %%%%%%%%%%%%%%%%%%%%
%%%%%%% Step1 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the derivative matrices are spelled out in the paper, they are 
disp('constructing Derivatives, elapsed time:')
tic

% first do the constant terms. These are inside the integral.
D11=A0*P+P*A0.';
D12=[];
D22=[];
for i=1:n_delay
    D11=D11+tauK*A{i}*subs(Q{i}.',th,-tau(i))+tauK*subs(Q{i},th,-tau(i))*A{i}.'+subs(S{i},th,0);
    D12=[D12 tauK*A{i}*subs(S{i},th,-tau(i))]; 
    D22=blkdiag(D22,(subs(-S{i},th,-tau(i))));
end
D21=D12.';


parfor i=1:n_delay
    D13{i}=tauK*A0*Q{i} + tauK*diff(Q{i},th);
    for j=1:n_delay
         D13{i}=D13{i}+tauK*A{j}*subs(var_swap(R{j,i},th,ksi),ksi,-tau(j));
    end
    D31{i}=D13{i}.';
    D23{i}=polynomial(zeros(n_delay*n_dim,n_dim));
    D33{i}=tauK*diff(S{i},th);
    D32{i}=D23{i}.';
end


parfor i=1:n_delay
    for j=1:n_delay
        G{i,j}=(diff(R{i,j},th)+diff(var_swap(R{j,i}.',th,ksi),ksi));
    end
end

toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enforce negativity of D 
disp('enforcing negativity of derivative')
%Now declare first spacing functions

%[prog, M, N] = sosjointpos_mat_ker_ndelay(prog,2*n_dim,orderth/2,ordernu/2,th,ksi,II);
disp('Calling for jointly positive Mat/Kernel, elapsed time:')
% 
% 
tic
%[prog, F, R] = sospos_mat_ker_ndelay(prog,(n_delay+2)*n_dim,orderth/2,ordernu/2,th,ksi,II);
[prog, D, E] = sosjointpos_mat_ker_ndelay_parallel(prog,(n_delay+2)*n_dim,orderth/2,ordernu/2,th,ksi,II);
toc
[prog, F2, H2] = sosspacing_mat_ker_ndelay_old(prog,(n_delay+1)*n_dim,n_dim,orderth,orderth*2,th,ksi,II);
D1=[D11 D12;D21 D22];
for i=1:n_delay
    V{i}=[D13{i};D23{i}];
    D0{i}= [ D1 1/a{i}*subs(V{i},th,(th-b{i})/a{i});
        1/a{i}*subs(V{i}.',th,(th-b{i})/a{i}) 1/a{i}*subs(D33{i},th,(th-b{i})/a{i})]; 
     for j=1:n_delay
         E0{i,j}=subs(subs(1/a{i}/a{j}*G{i,j},th,(th-b{i})/a{i}),ksi,(ksi-b{j})/a{j});
     end
end


 if orderth>0
    for i=1:n_delay
        [prog,bigSD{i}] = sosposmatrvar(prog,(n_delay+2)*n_dim,orderth-2,[th]);
    end
else
    for i=1:n_delay
        bigSD{i}=polynomial(zeros((n_delay+2)*n_dim));
    end
end


for i=1:n_delay
    prog = sosmateq(prog,D{i}+D0{i}+F2{i}+0*g{i}*bigSD{i});
    for j=1:n_delay % the latter j>1 define constraints
            prog = sosmateq(prog,E{i,j}+[zznK zz3; zz3.' E0{i,j}]+H2{i,j});
    end
end


toc
disp('TOTAL POLYNOMIAL TIME:')
toc(total)
disp('Computing Solution')


disp('Computing Solution')
prog = sossolve(prog);
%% Conclusion:
if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
    disp('The System is STABLE.')
elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
    disp('The System is likely STABLE. However, Double-check the precision.')
elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
    disp('The System is probably NOT STABLE.')
else
    disp('Unable to definitively determine stability. Numerical errors dominating or at the limit of stability.')
end



 
 

% 
% %  % % First check positivity of the functional
% 
% Pn=sosgetsol(prog,P);
% for i=1:n_delay
%     Qn{i}=sosgetsol(prog,Q{i});
%     Sn{i}=sosgetsol(prog,S{i});
%     for j=i:n_delay
%         Rn{i,j}=sosgetsol(prog,R{i,j});
%     end
% end
% parfor k=1:1000
%  ndim=length(Q{1});
%  nvec=6;
%         xtest=(-10 + (10+10).*rand(nvec,ndim))'*monomials([th],0:(nvec-1));
%      xtestksi=subs(xtest,th,ksi);
% % for i=1:n_delay
% %         xtest{i}=(-10 + (10+10).*rand(nvec,ndim))'*monomials([th],0:(nvec-1));
% %     xtestksi{i}=subs(xtest{i},th,ksi);
% % end
%     xtest0=subs(xtest,th,0);
% i1temp=tauK*xtest0.'*Pn*xtest0;
% i2temp=0;
% i3temp=0;
% i4temp=0;
% i5temp=0;
% 
% %
% for i=1:n_delay
%     i2temp=i2temp+tauK*int(xtest0.'*Qn{i}*xtest,th,-tau(i),0);
%     i3temp=i3temp+tauK*int(xtest.'*Qn{i}.'*xtest0,th,-tau(i),0);
%     i4temp=i4temp+tauK*int(xtest.'*Sn{i}.'*xtest,th,-tau(i),0);
%     for j=i:n_delay
%         i5temp=i5temp+int(int(xtest.'*Rn{i,j}*xtestksi,th,-tau(i),0),ksi,-tau(j),0);
%     end
% end
% % i1temp
% % i2temp
% % i3temp
% % i4temp
% % i5temp
% sum(k)=i1temp+i2temp+i3temp+i4temp+i5temp;
% end
% min(double(sum))


% %  % % check negativity of the derivative
% 
% 
% D11=A0*P+P*A0';
% D12=[];
% D22=[];
% for i=1:n_delay
%     D11=D11+tauK*A{i}*subs(Q{i},th,-tau(i)).'+tauK*subs(Q{i}.',th,-tau(i))*A{i}.'+subs(S{i},th,0);
%     D12=[D12 tauK*A{i}*subs(S{i},th,-tau(i))]; 
%     D22=blkdiag(D22,(subs(-S{i},th,-tau(i))));
% end
% D21=D12.';
% 
% parfor i=1:n_delay
%     D13{i}=tauK*A0*Q{i} + tauK*diff(Q{i},th);
%     for j=1:n_delay
%          D13{i}=D13{i}+tauK*A{j}*subs(var_swap(R{j,i},th,ksi),ksi,-tau(j));
%     end
%     D31{i}=D13{i}.';
%     D23{i}=polynomial(zeros(n_delay*n_dim,n_dim));
%     D33{i}=tauK*diff(S{i},th);
%     D32{i}=D23{i}.';
% end
% 
% parfor i=1:n_delay
%     for j=1:n_delay
%         G{i,j}=(diff(R{i,j},th)+diff(var_swap(R{j,i}.',th,ksi),ksi));
%     end
% end
% 
% 
% D11n=sosgetsol(prog,D11);
% for i=1:n_delay
%     D12n{i}=sosgetsol(prog,tauK*A{i}*subs(S{i},th,-tau(i)));
%     D22n{i}=sosgetsol(prog,(subs(-S{i},th,-tau(i))));
% 
% %    Dn{i}=sosgetsol(prog,[D11 D12 D13{i}; D21 D22 D23{i}; D31{i} D32{i} D33{i}]);
%     D13n{i}=sosgetsol(prog,D13{i});
%     D31n{i}=sosgetsol(prog,D31{i});
%     D33n{i}=sosgetsol(prog,D33{i});
%     Sn{i}=sosgetsol(prog,S{i});
%     for j=i:n_delay
%         Gn{i,j}=sosgetsol(prog,G{i,j});
%     end
% end
% for k=1:400
%  ndim=length(D11);
%  nvec=6;
%         xtest=(-1 + (1+1).*rand(nvec,ndim))'*monomials([th],0:(nvec-1));
%      xtestksi=subs(xtest,th,ksi);
%     xtest0=subs(xtest,th,0);
%     xtestd{1}=subs(xtest,th,-tau(1));
% %    xtestd{2}=subs(xtest,th,-tau(2));
% i1temp=tauK*xtest0.'*D11n*xtest0;
% 
% i2temp=0;
% i3temp=0;
% i4temp=0;
% i5temp=0;
% i6temp=0;
% i7temp=0;
% for i=1:n_delay
%     i2temp=i2temp+tauK*xtest0.'*D12n{i}*xtestd{i}+tauK*xtestd{i}.'*D12n{i}.'*xtest0 ;
%     i3temp=i3temp+tauK*xtestd{i}.'*D22n{i}*xtestd{i} ;
%     i4temp=i4temp+int(xtest0.'*D13n{i}*xtest,th,-tau(i),0);
%     i5temp=i5temp+int(xtest.'*D31n{i}.'*xtest0,th,-tau(i),0);
%     i6temp=i6temp+int(xtest.'*D33n{i}.'*xtest,th,-tau(i),0);
%     for j=i:n_delay
%         i7temp=i7temp+int(int(xtest.'*Gn{i,j}*xtestksi,th,-tau(i),0),ksi,-tau(j),0);
%     end
% end
% % i1temp
% % i2temp
% % i3temp
% % i4temp
% % i5temp
% dsum(k)=i1temp+i2temp+i3temp+i4temp+i5temp+i6temp+i7temp;
% end
% max(double(dsum))


% % %  % % check the spacing function
% 
% for i=1:n_delay
%     F2n{i}=sosgetsol(prog,F2{i});
%     for j=i:n_delay
%         H2n{i,j}=sosgetsol(prog,H2{i,j});
%     end
% end
% 
% for k=1:400
%  ndim=length(D11);
%  nvec=6;
%         xtest=(-1 + (1+1).*rand(nvec,ndim))'*monomials([th],0:(nvec-1));
%      xtestksi=subs(xtest,th,ksi);
%     xtest0=subs(xtest,th,0);
%     xtestd{1}=subs(xtest,th,-tau(1));
% itemp11=0;
% itemp22=0;
% for i=1:n_delay
%     itemp11=itemp11+int([xtest0.' xtestd{i}.' xtest.']*F2n{i}*[xtest0; xtestd{i}; xtest],th,-tau(1),0);
%     for j=i:n_delay
%     itemp22=itemp22+int(int([xtest0.' xtestd{i}.' xtest.']*H2n{i}*[xtest0; xtestd{i}; xtestksi],th,-tau(1),0),ksi,-tau(1),0);
%     end
% end
% dsum(k)=itemp11+itemp22;
% end
% max(double(dsum))


% % %  % % check the positivity
% 
% for i=1:n_delay
%     Dn{i}=sosgetsol(prog,D{i});
%     for j=i:n_delay
%         En{i,j}=sosgetsol(prog,E{i,j});
%     end
% end
% 
% for k=1:400
%  ndim=length(D11);
%  nvec=6;
%         xtest=(-1 + (1+1).*rand(nvec,ndim))'*monomials([th],0:(nvec-1));
%      xtestksi=subs(xtest,th,ksi);
%     xtest0=subs(xtest,th,0);
%     xtestd{1}=subs(xtest,th,-tau(1));
% itemp11=0;
% itemp22=0;
% for i=1:n_delay
%     itemp11=itemp11+int([xtest0.' xtestd{i}.' xtest.']*Dn{i}*[xtest0; xtestd{i}; xtest],th,-tau(1),0);
%     for j=i:n_delay
%     itemp22=itemp22+int(int([xtest0.' xtestd{i}.' xtest.']*En{i}*[xtest0; xtestd{i}; xtestksi],th,-tau(1),0),ksi,-tau(1),0);
%     end
% end
% dsum(k)=itemp11+itemp22;
% end
% min(double(dsum))


% %  % % check the positivity

% for i=1:n_delay
%     D0n{i}=sosgetsol(prog,D0{i});
%     for j=i:n_delay
%         E0n{i,j}=sosgetsol(prog,[zznK zz3; zz3.' E0{i,j}]);
%     end
% end
% 
% for k=1:400
%  ndim=length(D11);
%  nvec=6;
%         xtest=(-1 + (1+1).*rand(nvec,ndim))'*monomials([th],0:(nvec-1));
%      xtestksi=subs(xtest,th,ksi);
%     xtest0=subs(xtest,th,0);
%     xtestd{1}=subs(xtest,th,-tau(1));
% itemp11=0;
% itemp22=0;
% for i=1:n_delay
%     itemp11=itemp11+int([xtest0.' xtestd{i}.' xtest.']*D0n{i}*[xtest0; xtestd{i}; xtest],th,-tau(1),0);
%     for j=i:n_delay
%     itemp22=itemp22+int(int([xtest0.' xtestd{i}.' xtest.']*E0n{i}*[xtest0; xtestd{i}; xtestksi],th,-tau(1),0),ksi,-tau(1),0);
%     end
% end
% dsum(k)=itemp11+itemp22;
% end
% max(double(dsum))

% 
% % Try it without the adjoint
% % D11=A0*P+P*A0';
% % D12=[];
% % D22=[];
% % for i=1:n_delay
% %     D11=D11+tauK*A{i}*subs(Q{i},th,-tau(i))+tauK*subs(Q{i}.',th,-tau(i))*A{i}.'+subs(S{i},th,0);
% %     D12=[D12 tauK*A{i}*subs(S{i},th,-tau(i))]; 
% %     D22=blkdiag(D22,(subs(-S{i},th,-tau(i))));
% % end
% % D21=D12.';
% % 
% % parfor i=1:n_delay
% %     D13{i}=tauK*A0*Q{i} + tauK*diff(Q{i},th);
% %     for j=1:n_delay
% %          D13{i}=D13{i}+tauK*A{j}*subs(var_swap(R{j,i},th,ksi),ksi,-tau(j));
% %     end
% %     D31{i}=D13{i}.';
% %     D23{i}=polynomial(zeros(n_delay*n_dim,n_dim));
% %     D33{i}=tauK*diff(S{i},th);
% %     D32{i}=D23{i}.';
% % end
% % 
% % parfor i=1:n_delay
% %     for j=1:n_delay
% %         G{i,j}=(diff(R{i,j},th)+diff(var_swap(R{j,i}.',th,ksi),ksi));
% %     end
% % end
% 
% D11n=tauK*sosgetsol(prog,A0*P);
% for i=1:n_delay
%     D11n=D11n+sosgetsol(prog,tauK^2*A{i}*subs(Q{i},th,-tau(i)).'+tauK/2*subs(S{i},th,0));
%     D12n{i}=sosgetsol(prog,tauK^2*A{i}*subs(S{i},th,-tau(i)));
%     D22n{i}=sosgetsol(prog,tauK/2*(subs(-S{i},th,-tau(i))));
% 
% %    Dn{i}=sosgetsol(prog,[D11 D12 D13{i}; D21 D22 D23{i}; D31{i} D32{i} D33{i}]);
%     D13n{i}=sosgetsol(prog,tauK*A0*Q{i} + tauK*diff(Q{i},th));
%     for j=1:n_delay
%          D13n{i}=D13n{i}+sosgetsol(prog,tauK*A{j}*subs(var_swap(R{j,i},th,ksi),ksi,-tau(j)));
%     end
% %    D31n{i}=sosgetsol(prog,D31{i});
%     D33n{i}=sosgetsol(prog,tauK/2*diff(S{i},th));
% %    Sn{i}=sosgetsol(prog,S{i});
%     for j=i:n_delay
%         Din{i,j}=sosgetsol(prog,diff(R{i,j},th));
%     end
% end
% for k=1:400
%  ndim=length(D11);
%  nvec=6;
%         xtest=(-1 + (1+1).*rand(nvec,ndim))'*monomials([th],0:(nvec-1));
%      xtestksi=subs(xtest,th,ksi);
%     xtest0=subs(xtest,th,0);
%     xtestd{1}=subs(xtest,th,-tau(1));
%     xtestd{2}=subs(xtest,th,-tau(2));
% i1temp=xtest0.'*D11n*xtest0;
% 
% i2temp=0;
% i3temp=0;
% i4temp=0;
% i5temp=0;
% i6temp=0;
% i7temp=0;
% for i=1:n_delay
%     i2temp=i2temp+xtest0.'*D12n{i}*xtestd{i};
%     i3temp=i3temp+xtestd{i}.'*D22n{i}*xtestd{i} ;
%     i4temp=i4temp+int(xtest0.'*D13n{i}*xtest,th,-tau(i),0);
% %    i5temp=i5temp+int(xtest.'*D31n{i}.'*xtest0,th,-tau(i),0);
%     i6temp=i6temp+int(xtest.'*D33n{i}.'*xtest,th,-tau(i),0);
%     for j=i:n_delay
%         i7temp=i7temp+int(int(xtest.'*Din{i,j}*xtestksi,th,-tau(i),0),ksi,-tau(j),0);
%     end
% end
% % i1temp
% % i2temp
% % i3temp
% % i4temp
% % i5temp
% dsum(k)=i1temp+i2temp+i3temp+i4temp+i5temp+i6temp+i7temp;
% end
% max(double(dsum))




